package com.example.gift_customization.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gift_customization.entities.MugDetails;
import com.example.gift_customization.entities.TshirtDetails;

public interface TshirtRepo extends JpaRepository<TshirtDetails,Long> {

	List<TshirtDetails> findByRequestedby(String attribute);

	List<TshirtDetails> findByOwner(String attribute);

}
