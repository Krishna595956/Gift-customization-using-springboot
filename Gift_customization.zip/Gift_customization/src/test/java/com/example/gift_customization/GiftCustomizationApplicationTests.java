package com.example.gift_customization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GiftCustomizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
