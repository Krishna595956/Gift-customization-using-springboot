package com.example.gift_customization.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gift_customization.entities.OwnerDetails;

public interface OwnerRepo extends JpaRepository<OwnerDetails,Long> {
	
	OwnerDetails findByEmail(String email);
}
