package com.example.gift_customization.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gift_customization.entities.Orders;

public interface OrdersRepo extends JpaRepository<Orders,Long> {


	Orders findByOrderedbyAndId(String customerEmail, Long id);

	Orders findByOrderedbyAndProductIdAndStatus(String customerEmail, Long id, String string);

	List<Orders> findByOrderedby(String attribute);

	Optional<Orders> findByProductIdAndOrderedby(Long productId, String customerEmail);

	List<Orders> findByOwner(String ownerEmail);

}
