package com.example.gift_customization.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gift_customization.entities.CustomerDetails;

public interface CustomerRepo extends JpaRepository<CustomerDetails,Long> {
	
	CustomerDetails findByEmail(String email);
}
