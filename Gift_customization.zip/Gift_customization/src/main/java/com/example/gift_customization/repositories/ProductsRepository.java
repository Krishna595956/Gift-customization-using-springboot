package com.example.gift_customization.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gift_customization.entities.Products;

public interface ProductsRepository extends JpaRepository<Products,Long> {

	List<Products> findByOwner(String attribute);

}
