package com.example.gift_customization.controllers;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.gift_customization.DTO.LoginDetails;
import com.example.gift_customization.entities.CustomerDetails;
import com.example.gift_customization.entities.FrameDetails;
import com.example.gift_customization.entities.MugDetails;
import com.example.gift_customization.entities.Orders;
import com.example.gift_customization.entities.OwnerDetails;
import com.example.gift_customization.entities.Products;
import com.example.gift_customization.entities.TshirtDetails;
import com.example.gift_customization.repositories.CustomerRepo;
import com.example.gift_customization.repositories.FrameRepo;
import com.example.gift_customization.repositories.MugRepo;
import com.example.gift_customization.repositories.OrdersRepo;
import com.example.gift_customization.repositories.OwnerRepo;
import com.example.gift_customization.repositories.ProductsRepository;
import com.example.gift_customization.repositories.TshirtRepo;
import com.example.gift_customization.services.EmailService;

import jakarta.persistence.criteria.Path;
import jakarta.servlet.http.HttpSession;

@Controller
public class CustomerController {

	@Autowired
	CustomerRepo customerRepository;

	@Autowired
	EmailService emailService;

	@Autowired
	ProductsRepository productsRepository;

	@Autowired
	OrdersRepo ordersRepository;

	@Autowired
	MugRepo mugRepository;

	@Autowired
	OwnerRepo ownerRepository;

	@Autowired
	TshirtRepo tshirtRepository;

	@Autowired
	FrameRepo frameRepository;

	@GetMapping("/")
	public String home(HttpSession session, Model model) {
		String email = (String) session.getAttribute("customerEmail");
		model.addAttribute("user", email);
		return "home";
	}

	@GetMapping("/usertype")
	public String usertype() {
		return "userType";
	}

	@GetMapping("/customerregister")
	public String ownerregister() {
		return "customerRegister";
	}

	@GetMapping("/customerlogin")
	public String ownerlogin() {
		return "customerLogin";
	}

	@GetMapping("/customize/{id}")
	public String customize(@PathVariable("id") Long id, HttpSession session) {
		session.setAttribute("shopid", id);
		return "selectType";
	}

	@GetMapping("/customerDashboard")
	public String customerDashboard(Model model, HttpSession session) {
		// Fetch the list of products
		List<Products> products = productsRepository.findAll();

		// Add products to the model
		model.addAttribute("products", products);

		// Add user email (check that it's not null)
		String customerEmail = (String) session.getAttribute("customerEmail");
		model.addAttribute("user", customerEmail);

		// Add logged-in status (make sure it's a Boolean)
		Boolean loggedin = (Boolean) session.getAttribute("loggedin");
		model.addAttribute("loggedin", loggedin);

		// Return the name of the view (home.html)
		return "home";
	}

	@PostMapping("/customerregister")
	public String registerCustomer(CustomerDetails customer, Model model) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

		if (customerRepository.findByEmail(customer.getEmail()) != null) {
			model.addAttribute("status", "Please register with a different email");
			return "customerRegister";
		}

		// Encrypt password before saving
		String encodedPassword = passwordEncoder.encode(customer.getPassword());
		customer.setPassword(encodedPassword);

		// Save the customer to the database
		customerRepository.save(customer);
		// Prepare email content
		String subject = "Welcome to [Your Company Name], " + customer.getFullname() + "!";
		String body = "Thank you for registering with [Your Company Name]! \n" + "Your account details:\n" + "Email: "
				+ customer.getEmail() + "\n"
				+ "**Please note:** This email does not contain your password for security reasons.\n"
				+ "You can now log in to your account at: [Your Login URL]\n\n"
				+ "We hope you enjoy using our services!\n\n" + "Sincerely,\n" + "[Your Company Name] Team";

		// Send email using Spring Boot email configuration (explained below)
		try {
			emailService.sendRegistrationEmail(customer.getEmail(), subject, body);
			model.addAttribute("status",
					"Registration successful. A confirmation email has been sent to " + customer.getEmail());
			return "customerLogin"; // Redirect to login page
		} catch (Exception e) {
			model.addAttribute("status", e);
			return "customerLogin"; // Redirect to login page with error message
		}
	}

	@PostMapping("/customerlogin")
	public String ownerlogin1(LoginDetails loginDetails, Model model, HttpSession session) {
		// Retrieve customer by email
		CustomerDetails customer = customerRepository.findByEmail(loginDetails.getEmail());

		// Check if customer exists
		if (customer == null) {
			model.addAttribute("status", "Invalid email or password");
			return "customerLogin"; // Return to login page
		}

		// Check password using BCryptPasswordEncoder
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		if (!passwordEncoder.matches(loginDetails.getPassword(), customer.getPassword())) {
			model.addAttribute("status", "Invalid email or password");
			return "customerLogin"; // Return to login page
		}

		// If login is successful, store the customer's details in the session
		session.setAttribute("customerEmail", customer.getEmail());
		session.setAttribute("customerName", customer.getFullname()); // Optional, for personalized dashboard
		session.setAttribute("userType", "customer");
		session.setAttribute("loggedin", true);
		// Redirect to the dashboard
		return "redirect:/customerDashboard"; // Redirect to dashboard page
	}

	@GetMapping("/customizetshirt")
	public String customizet() {
		return "customizeTshirt";
	}

	@GetMapping("/customizemug")
	public String customizem() {
		return "customizeMug";
	}

	@GetMapping("/customizeframe")
	public String customizeframe() {
		return "customizeFrame";
	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	@GetMapping("/shopnow")
	public String shopnow(Model model) {
		List<Products> products = productsRepository.findAll();
		model.addAttribute("products", products);
		return "shopnow";
	}

	@GetMapping("orderProduct/{id}")
	public String orderProduct(Model model, @PathVariable("id") Long id, HttpSession session) {
		// Check if the customer is logged in
		String customerEmail = (String) session.getAttribute("customerEmail");
		if (customerEmail == null) {
			model.addAttribute("errorMessage", "Please log in to place an order.");
			return "redirect:/customerlogin"; // Redirect to the login page if customer is not logged in
		}

		Optional<Products> product = productsRepository.findById(id);

		// Check if the product exists
		if (product.isPresent()) {
			Products p = product.get();

			// Check for existing orders by the same customer for the same product and with
			// "PENDING" status
			Orders existingOrder = ordersRepository.findByOrderedbyAndProductIdAndStatus(customerEmail, id, "PENDING");

			if (existingOrder != null) {
				// If a pending order exists, return an error message
				model.addAttribute("errorMessage", "You have already placed an order for this product.");
			} else {
				// Create a new order if no pending order exists
				Orders order = new Orders();
				order.setImageUrl(p.getImageUrl());
				order.setOrderedby(customerEmail); // Using the session attribute for the customer
				order.setOwner(p.getOwner());
				order.setProductName(p.getProductName());
				order.setProductPrice(p.getProductPrice());
				order.setStatus("PENDING");
				order.setProductId(id);

				// Save the order to the database
				ordersRepository.save(order);

				// Add success message to model
				model.addAttribute("successMessage", "Order placed successfully");
			}
		} else {
			// If the product doesn't exist
			model.addAttribute("errorMessage", "Product not found.");
		}

		return "redirect:/shopnow"; // Redirect to the shop now page after placing the order or showing error
	}

	@GetMapping("/customerorders")
	public String customerorders(Model model, HttpSession session) {
		List<Orders> orders = ordersRepository.findByOrderedby((String) session.getAttribute("customerEmail"));
		model.addAttribute("orders", orders);

		return "customerorders";
	}

	@PostMapping("/deleteOrder/{id}")
	public String deleteOrder(@PathVariable("id") Long productId, HttpSession session, Model model) {
		// Check if the customer is logged in
		String customerEmail = (String) session.getAttribute("customerEmail");
		if (customerEmail == null) {
			model.addAttribute("errorMessage", "Please log in to delete an order.");
			return "redirect:/customerlogin"; // Redirect to login page if not logged in
		}

		// Find the order by the productId and the customer who ordered it
		Optional<Orders> orderOpt = ordersRepository.findByProductIdAndOrderedby(productId, customerEmail);
		if (orderOpt.isPresent()) {
			Orders order = orderOpt.get();

			// Check if the order is pending (can only delete pending orders)
			if ("PENDING".equals(order.getStatus())) {
				// Delete the order
				ordersRepository.delete(order);
				model.addAttribute("successMessage", "Order has been deleted successfully.");
			} else {
				model.addAttribute("errorMessage", "Order cannot be deleted because it is not pending.");
			}
		} else {
			model.addAttribute("errorMessage", "Order not found.");
		}

		return "redirect:/customerorders"; // Redirect back to the orders page
	}

	@PostMapping("/acceptOrder/{id}")
	public String acceptOrder(@PathVariable("id") Long id, HttpSession session, Model model) {
		// Print the order ID to verify it's being passed correctly
		System.out.println("Received order ID: " + id);

		// Retrieve the owner email from the session
		String customerEmail = (String) session.getAttribute("ownerEmail");
		if (customerEmail == null) {
			System.out.println("No ownerEmail found in session. Redirecting to login.");
			return "redirect:/ownerlogin"; // Redirect to login if ownerEmail is not in session
		}

		// Find the order by ID
		Optional<Orders> order = ordersRepository.findById(id);
		if (order.isPresent()) {
			Orders o = order.get();

			// Update order status to "ACCEPTED"
			o.setStatus("ACCEPTED");

			// Save the updated order
			ordersRepository.save(o);

			// Print the updated order status
			System.out.println("Updated order status: " + o.getStatus());

			// Redirect to the orders page after the update
			return "redirect:/ownerOrders";
		}

		// If the order is not found, log a message and redirect
		System.out.println("Order with ID " + id + " not found.");
		return "redirect:/ownerOrders";
	}

	@PostMapping("/rejectOrder/{id}")
	public String rejectOrder(@PathVariable("id") Long id, HttpSession session) {
		String customerEmail = (String) session.getAttribute("ownerEmail");
		if (customerEmail == null) {
			return "redirect:/ownerlogin";
		}

		Optional<Orders> order = ordersRepository.findById(id);
		if (order.isPresent()) {
			Orders o = order.get();
			if (o.getOwner().equals(customerEmail) && o.getStatus().equals("PENDING")) {
				o.setStatus("REJECTED");
				ordersRepository.save(o);
				return "redirect:/ownerOrders"; // Or wherever the owner is redirected after rejecting
			}
		}

		return "redirect:/ownerOrders"; // In case the conditions are not met
	}

	@GetMapping("/orderdetails/{id}")
	public String getOrderDetails(@PathVariable("id") Long id, Model model) {
		Optional<Orders> order = ordersRepository.findById(id);
		if (order.isPresent()) {
			model.addAttribute("order", order.get());

			// Assuming you are retrieving customer details from the database or session
			CustomerDetails customer = customerRepository.findByEmail(order.get().getOrderedby());
			model.addAttribute("customer", customer);

			return "orderdetails";
		} else {
			return "redirect:/ownerOrders";
		}
	}

	@PostMapping("/deleteCustomMugOrder/{id}")
	public String deleteCustomMugOrder(@PathVariable Long id, HttpSession session) {
		// Retrieve the customer's email from the session to ensure they're logged in
		String customerEmail = (String) session.getAttribute("customerEmail");
		if (customerEmail == null) {
			// Redirect to login page if not logged in
			return "redirect:/customerlogin";
		}

		// Find the mug order by ID
		Optional<MugDetails> mugOrder = mugRepository.findById(id);
		if (mugOrder.isPresent()) {
			// Ensure the order belongs to the logged-in customer before deleting
			if (mugOrder.get().getRequestedby().equals(customerEmail)) {
				// Delete the mug order
				mugRepository.deleteById(id);
			} else {
				// If the order doesn't belong to the customer, return an error page
				return "errorPage"; // You can customize this to a relevant error view
			}
		}

		// Redirect to the customer's orders page after deletion
		return "redirect:/customerCustomizedOrders";
	}

	@PostMapping("/ordercustomizedmug")
	public String orderMug(HttpSession session, MugDetails mug, Model model) {
		// Retrieve session attributes
		String customerEmail = (String) session.getAttribute("customerEmail");
		Long shopId = (Long) session.getAttribute("shopid");

		// Validate session attributes
		if (customerEmail == null || shopId == null) {
			model.addAttribute("error", "You must be logged in to place an order.");
			return "customerLogin"; // Redirect to login page if session attributes are missing
		}

		// Retrieve owner details using the shopId from ownerRepository
		Optional<OwnerDetails> ownerOptional = ownerRepository.findById(shopId);
		if (ownerOptional.isPresent()) {
			OwnerDetails owner = ownerOptional.get(); // Get the owner details
			// Set the details on the MugDetails object
			mug.setOrderStatus("PENDING");
			mug.setRequestedby(customerEmail);
			mug.setOwner(owner.getEmail()); // Set the owner's email from the Owner entity

			// Save the order to the repository
			mugRepository.save(mug);

			// Add success message to the model
			model.addAttribute("status", "Order placed successfully");

			// Return the view to show the status message or go to the next page
			return "customizeMug"; // Return the view name where the status will be displayed
		} else {
			// If owner is not found, display an error message
			model.addAttribute("error", "Shop not found.");
			return "customerLogin"; // Return to the login page or another error page
		}
	}

	@GetMapping("/customizedOrders")
	public String getCustomizedMugOrders(Model model, HttpSession session) {
		List<MugDetails> orders = mugRepository.findByOwner((String) session.getAttribute("ownerEmail"));
		model.addAttribute("orders", orders);
		List<TshirtDetails> orders1 = tshirtRepository.findByOwner((String) session.getAttribute("ownerEmail"));
		model.addAttribute("tshirtOrders", orders1);
		List<FrameDetails> orders2 = frameRepository.findByOwner((String) session.getAttribute("ownerEmail"));
		model.addAttribute("frameOrders", orders2);
		return "customizedOrders"; // Return the name of the HTML template
	}

	@GetMapping("/customerCustomizedOrders")
	public String getCustomizedOrders(Model model, HttpSession session) {
		// Retrieve the customer email from the session
		String customerEmail = (String) session.getAttribute("customerEmail");

		// Check if customerEmail is available in the session
		if (customerEmail == null) {
			return "redirect:/customerlogin"; // Redirect to login if the customer email is not found in the session
		}

		try {
			// Fetch Mug, Frame, and T-shirt details from the respective repositories
			List<MugDetails> mugOrders = mugRepository.findByRequestedby(customerEmail);
			List<FrameDetails> frameOrders = frameRepository.findByRequestedby(customerEmail);
			List<TshirtDetails> tshirtOrders = tshirtRepository.findByRequestedby(customerEmail);

			// Add each order list to the model
			model.addAttribute("orders", mugOrders);
			model.addAttribute("frameOrders", frameOrders);
			model.addAttribute("tshirtOrders", tshirtOrders);

			// Return the view name (template) to render
			return "customerCustomizedOrders";
		} catch (Exception e) {
			// Log the error and handle it gracefully
			e.printStackTrace();
			model.addAttribute("error",
					"An error occurred while fetching your customized orders. Please try again later.");
			return "errorPage"; // You can create a custom error page for such issues
		}
	}

	@PostMapping("/acceptcustomOrder/{id}")
	public String acceptOrder(@PathVariable Long id, Model model) {
		// Fetch the mug order by id
		Optional<MugDetails> mugOrderOpt = mugRepository.findById(id);

		if (mugOrderOpt.isPresent()) {
			MugDetails mugOrder = mugOrderOpt.get();
			mugOrder.setOrderStatus("ACCEPTED"); // Update the status to ACCEPTED
			mugRepository.save(mugOrder); // Save the updated mug order

			model.addAttribute("status", "Order accepted successfully.");
		} else {
			model.addAttribute("status", "Order not found.");
		}

		return "redirect:/customizedOrders"; // Redirect to the orders page after accepting
	}

	@PostMapping("/rejectCustomTshirtOrder/{id}")
	public String rejectCustomTshirtOrder(@PathVariable Long id, HttpSession session, Model model) {
		// Validate session to ensure the user is logged in
		String customerEmail = (String) session.getAttribute("ownerEmail");
		if (customerEmail == null) {
			// Redirect to login page if the user is not logged in
			return "redirect:/ownerlogin";
		}

		// Find the T-shirt order by ID
		Optional<TshirtDetails> tshirtOrder = tshirtRepository.findById(id);
		if (tshirtOrder.isPresent()) {
			TshirtDetails order = tshirtOrder.get();

			// Ensure the order belongs to the logged-in customer
			if (order.getRequestedby().equals(customerEmail)) {
				// Update the order status to "REJECTED"
				order.setOrderStatus("REJECTED");
				tshirtRepository.save(order);

			} else {
				return "redirect:/ownerlogin"; // Customize with an appropriate error view
			}
		} else {
			// If the order is not found, display an error message
			model.addAttribute("error", "Order not found.");
			return "redirect:/ownerlogin"; // Customize with an appropriate error view
		}

		// Redirect to the customer's orders page
		return "redirect:/customizedOrders";
	}

	@PostMapping("/acceptCustomTshirtOrder/{id}")
	public String acceptCustomTshirtOrder(@PathVariable Long id, HttpSession session, Model model) {
		// Validate session to ensure the user is logged in
		String customerEmail = (String) session.getAttribute("ownerEmail");
		if (customerEmail == null) {
			// Redirect to login page if the user is not logged in
			return "redirect:/ownerlogin";
		}

		// Find the T-shirt order by ID
		Optional<TshirtDetails> tshirtOrder = tshirtRepository.findById(id);
		if (tshirtOrder.isPresent()) {
			TshirtDetails order = tshirtOrder.get();

			// Ensure the order belongs to the logged-in customer
			if (order.getRequestedby().equals(customerEmail)) {
				// Update the order status to "REJECTED"
				order.setOrderStatus("ACCEPTED");
				tshirtRepository.save(order);

			} else {
				return "redirect:/ownerlogin"; // Customize with an appropriate error view
			}
		} else {
			// If the order is not found, display an error message
			model.addAttribute("error", "Order not found.");
			return "redirect:/ownerlogin"; // Customize with an appropriate error view
		}

		// Redirect to the customer's orders page
		return "redirect:/customizedOrders";
	}

	@PostMapping("/rejectcustomOrder/{id}")
	public String rejectOrder(@PathVariable Long id, Model model) {
		// Fetch the mug order by id
		Optional<MugDetails> mugOrderOpt = mugRepository.findById(id);

		if (mugOrderOpt.isPresent()) {
			MugDetails mugOrder = mugOrderOpt.get();
			mugOrder.setOrderStatus("REJECTED"); // Update the status to REJECTED
			mugRepository.save(mugOrder); // Save the updated mug order

			model.addAttribute("status", "Order rejected successfully.");
		} else {
			model.addAttribute("status", "Order not found.");
		}

		return "redirect:/customizedOrders"; // Redirect to the orders page after rejecting
	}

	@GetMapping("/customorderdetails/{id}")
	public String getOrderDetails1(@PathVariable Long id, Model model) {
		// Fetch the order details by ID
		Optional<MugDetails> orderOptional = mugRepository.findById(id);

		if (orderOptional.isPresent()) {
			MugDetails order = orderOptional.get();

			// Fetch the customer details using the 'requestedby' field (customer email)
			String requestedByEmail = order.getRequestedby();
			CustomerDetails customer = customerRepository.findByEmail(requestedByEmail);
			model.addAttribute("order", order);
			model.addAttribute("customer", customer);

		} else {
			model.addAttribute("error", "Order not found.");
		}

		return "customOrderDetails"; // Name of the Thymeleaf template to display the details
	}

	@PostMapping("/orderCustomTshirt")
	public String orderTshirt(HttpSession session, TshirtDetails tshirt, Model model) {
		// Retrieve session attributes
		String customerEmail = (String) session.getAttribute("customerEmail");
		Long shopId = (Long) session.getAttribute("shopid");

		// Validate session attributes
		if (customerEmail == null || shopId == null) {
			model.addAttribute("error", "You must be logged in to place an order.");
			return "customerLogin"; // Redirect to login page if session attributes are missing
		}

		// Retrieve owner details using the shopId from ownerRepository
		Optional<OwnerDetails> ownerOptional = ownerRepository.findById(shopId);
		if (ownerOptional.isPresent()) {
			OwnerDetails owner = ownerOptional.get(); // Get the owner details
			// Set the details on the TshirtDetails object
			tshirt.setOrderStatus("PENDING");
			tshirt.setRequestedby(customerEmail);
			tshirt.setOwner(owner.getEmail()); // Set the owner's email from the Owner entity

			// Save the order to the repository
			tshirtRepository.save(tshirt);

			// Add success message to the model
			model.addAttribute("status", "Order placed successfully");

			// Return the view to show the status message or go to the next page
			return "customizetshirt"; // Return the view name where the status will be displayed
		} else {
			// If owner is not found, display an error message
			model.addAttribute("error", "Shop not found.");
			return "customerLogin"; // Return to the login page or another error page
		}
	}

	@PostMapping("/orderCustomizedFrame")
	public String orderFrame(HttpSession session, FrameDetails frame, Model model) {
		// Retrieve session attributes
		String customerEmail = (String) session.getAttribute("customerEmail");
		Long shopId = (Long) session.getAttribute("shopid");

		// Validate session attributes
		if (customerEmail == null || shopId == null) {
			model.addAttribute("error", "You must be logged in to place an order.");
			return "customerLogin"; // Redirect to login page if session attributes are missing
		}

		// Retrieve owner details using the shopId from ownerRepository
		Optional<OwnerDetails> ownerOptional = ownerRepository.findById(shopId);
		if (ownerOptional.isPresent()) {
			OwnerDetails owner = ownerOptional.get(); // Get the owner details

			// Set the details on the FrameDetails object
			frame.setOrderStatus("PENDING");
			frame.setRequestedby(customerEmail);
			frame.setOwner(owner.getEmail()); // Set the owner's email from the Owner entity

			// Save the order to the repository
			frameRepository.save(frame);

			// Add success message to the model
			model.addAttribute("status", "Frame order placed successfully");

			// Return the view to show the status message or go to the next page
			return "customizeFrame"; // Return the view name where the status will be displayed
		} else {
			// If owner is not found, display an error message
			model.addAttribute("error", "Shop not found.");
			return "customerLogin"; // Return to the login page or another error page
		}
	}

	@GetMapping("/customtshirtdetails/{id}")
	public String getCustomTshirtDetails(@PathVariable Long id, Model model) {
		// Fetch the T-shirt order details using the ID
		Optional<TshirtDetails> tshirtOptional = tshirtRepository.findById(id);
		if (tshirtOptional.isPresent()) {
			TshirtDetails tshirt = tshirtOptional.get();

			// Fetch the customer details using the `requestedby` field
			String customerEmail = tshirt.getRequestedby();
			CustomerDetails customer = customerRepository.findByEmail(customerEmail);

			// Add T-shirt and customer details to the model
			model.addAttribute("order", tshirt);
			model.addAttribute("customer", customer);

			// Return the view for displaying the details
			return "customTshirtDetails";
		} else {
			// T-shirt order not found, display error
			model.addAttribute("error", "T-shirt order not found.");
			return "errorPage"; // Customize this with a relevant error view
		}
	}

	@PostMapping("/acceptCustomFrameOrder/{id}")
	public String acceptCustomFrameOrder(@PathVariable Long id, Model model) {
		// Fetch the frame order from the repository using the provided ID
		Optional<FrameDetails> frameOrderOptional = frameRepository.findById(id);

		if (frameOrderOptional.isPresent()) {
			FrameDetails frameOrder = frameOrderOptional.get();

			// Check if the order is in 'PENDING' status
			if ("PENDING".equals(frameOrder.getOrderStatus())) {
				// Update the order status to 'ACCEPTED'
				frameOrder.setOrderStatus("ACCEPTED");

				// Save the updated frame order
				frameRepository.save(frameOrder);

				// Add a success message
				model.addAttribute("status", "Order Accepted Successfully");
			} else {
				// If the order status is not pending, show a message that it's already
				// processed
				model.addAttribute("error", "This order cannot be accepted as it is not in a pending state.");
			}
		} else {
			// If the order is not found, display an error message
			model.addAttribute("error", "Frame Order not found.");
		}

		// Redirect to a page to view the updated order status
		return "redirect:/customizedOrders"; // Change to the appropriate page URL
	}

	@PostMapping("/rejectCustomFrameOrder/{id}")
	public String rejectCustomFrameOrder(@PathVariable Long id, Model model) {
		// Fetch the frame order from the repository using the provided ID
		Optional<FrameDetails> frameOrderOptional = frameRepository.findById(id);

		if (frameOrderOptional.isPresent()) {
			FrameDetails frameOrder = frameOrderOptional.get();

			// Check if the order is in 'PENDING' status
			if ("PENDING".equals(frameOrder.getOrderStatus())) {
				// Update the order status to 'REJECTED'
				frameOrder.setOrderStatus("REJECTED");

				// Save the updated frame order
				frameRepository.save(frameOrder);

				// Add a success message
				model.addAttribute("status", "Order Rejected Successfully");
			} else {
				// If the order status is not pending, show a message that it's already
				// processed
				model.addAttribute("error", "This order cannot be rejected as it is not in a pending state.");
			}
		} else {
			// If the order is not found, display an error message
			model.addAttribute("error", "Frame Order not found.");
		}

		// Redirect to a page to view the updated order status
		return "redirect:/customizedOrders"; // Change to the appropriate page URL where orders are listed
	}

	@GetMapping("/customframeorderdetails/{id}")
	public String customFrameOrderDetails(@PathVariable Long id, Model model) {
		// Step 1: Fetch the custom frame order by ID from the frame repository
		Optional<FrameDetails> frameOrderOptional = frameRepository.findById(id);

		if (frameOrderOptional.isPresent()) {
			FrameDetails frameOrder = frameOrderOptional.get();

			// Step 2: Fetch customer details using the 'requestedby' field from the
			// customer repository
			String customerEmail = frameOrder.getRequestedby();
			CustomerDetails customer = customerRepository.findByEmail(customerEmail);

			// Step 3: Add both frame order details and customer details to the model
			model.addAttribute("order", frameOrder);
			model.addAttribute("customer", customer);

			// Return the view that will display the order and customer details
			return "customframeorderdetails"; // This is the Thymeleaf template name
		} else {
			model.addAttribute("error", "Frame order not found.");
			return "error"; // Redirect to error page if order is not found
		}
	}

	@PostMapping("/deleteCustomFrameOrder/{id}")
	public String deleteCustomFrameOrder(@PathVariable("id") Long id, Model model) {
		try {
			// Check if the order with the given ID exists
			if (frameRepository.existsById(id)) {
				// Delete the frame order by its ID
				frameRepository.deleteById(id);
				// Add a success message to the model to inform the user
				model.addAttribute("message", "Frame order successfully deleted.");
			} else {
				// If order does not exist, add a message to the model
				model.addAttribute("message", "Frame order not found.");
			}
		} catch (Exception e) {
			// If an error occurs during deletion, log and display an error message
			e.printStackTrace();
			model.addAttribute("message", "An error occurred while trying to delete the frame order.");
		}
		// Redirect or return the appropriate view (e.g., a list of orders)
		return "redirect:/customerCustomizedOrders"; // Redirect to the page showing all orders
	}
	
	@PostMapping("/deleteCustomTshirtOrder/{id}")
	public String deleteCustomTshirtOrder(@PathVariable("id") Long id, Model model) {
	    try {
	        // Check if the order with the given ID exists
	        if (tshirtRepository.existsById(id)) {
	            // Delete the t-shirt order by its ID
	            tshirtRepository.deleteById(id);
	            // Add a success message to the model to inform the user
	            model.addAttribute("message", "T-shirt order successfully deleted.");
	        } else {
	            // If the order does not exist, add a message to the model
	            model.addAttribute("message", "T-shirt order not found.");
	        }
	    } catch (Exception e) {
	        // If an error occurs during deletion, log and display an error message
	        e.printStackTrace();
	        model.addAttribute("message", "An error occurred while trying to delete the t-shirt order.");
	    }
	    // Redirect to the page showing all orders (customized orders)
	    return "redirect:/customerCustomizedOrders"; // Adjust the redirect URL based on your app flow
	}


}
