package com.example.gift_customization.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gift_customization.entities.MugDetails;

public interface MugRepo extends JpaRepository<MugDetails,Long> {

	List<MugDetails> findByRequestedby(String attribute);

	List<MugDetails> findByOwner(String attribute);

}
