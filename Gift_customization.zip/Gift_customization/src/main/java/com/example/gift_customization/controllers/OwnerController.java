package com.example.gift_customization.controllers;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.gift_customization.DTO.LoginDetails;
import com.example.gift_customization.entities.Orders;
import com.example.gift_customization.entities.OwnerDetails;
import com.example.gift_customization.entities.Products;
import com.example.gift_customization.repositories.OrdersRepo;
import com.example.gift_customization.repositories.OwnerRepo;
import com.example.gift_customization.repositories.ProductsRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class OwnerController {

	@Autowired
	private OwnerRepo ownerRepository;

	@Autowired
	ProductsRepository productsRepository;
	
	@Autowired
	OrdersRepo ordersRepository;

	@GetMapping("/ownerlogin")
	public String ownerLogin() {
		return "ownerLogin"; // Assuming your owner login template name

	}

	@GetMapping("/ownerregister")
	public String oreg() {
		return "ownerRegister";
	}

	@GetMapping("/ownerDashboard")
	public String ownerDashboard(Model model, HttpSession session) {
		// Fetch products based on the owner's email stored in the session
		String ownerEmail = (String) session.getAttribute("ownerEmail");
		if (ownerEmail == null) {
			return "redirect:/ownerLogin"; // Redirect to login if session is invalid
		}

		List<Products> products = productsRepository.findByOwner(ownerEmail); // Fetch products
		model.addAttribute("products", products); // Add products to the model

		// Log product details in the terminal
		System.out.println("Products owned by: " + ownerEmail);
		return "ownerDashboard"; // Render the owner dashboard template
	}

	@PostMapping("/ownerregister")
	public String registerOwner(OwnerDetails owner, Model model) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

		if (ownerRepository.findByEmail(owner.getEmail()) != null) {
			model.addAttribute("Status", "Please register with a different email");
			return "ownerRegister";
		}

		// Encrypt password before saving
		String encodedPassword = passwordEncoder.encode(owner.getPassword());
		owner.setPassword(encodedPassword);

		// Save the owner to the database
		ownerRepository.save(owner);
		model.addAttribute("Status", "Registration successful");
		return "ownerLogin"; // Assuming you want to redirect to login page after registration
	}

	@PostMapping("/ownerlogin")
	public String ownerLogin1(LoginDetails loginDetails, Model model, HttpSession session) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

		// Retrieve owner by email
		OwnerDetails owner = ownerRepository.findByEmail(loginDetails.getEmail());

		if (owner == null) {
			// If the email does not exist
			model.addAttribute("errorMessage", "Invalid email or password");
			return "ownerLogin"; // Redirect back to login page with error
		}

		// Verify the password using BCrypt
		if (!passwordEncoder.matches(loginDetails.getPassword(), owner.getPassword())) {
			// If the password does not match
			model.addAttribute("errorMessage", "Invalid email or password");
			return "ownerLogin";
		}

		// If login is successful, store user details in the session
		session.setAttribute("ownerEmail", owner.getEmail());
		session.setAttribute("userType", "owner");

		// Redirect to the owner dashboard
		return "redirect:/ownerDashboard"; // Assuming "ownerDashboard" is the template for the dashboard
	}

	@PostMapping("/addProduct")
	public String addProduct(Products product, Model model, HttpSession session) {
		if (session.getAttribute("ownerEmail") == null) {
			model.addAttribute("errorMessage", "Please log in to add a product.");
			return "ownerLogin";
		}

		try {
			product.setOwner((String)session.getAttribute("ownerEmail"));
			productsRepository.save(product);
			model.addAttribute("successMessage", "Product added successfully!");
			return "redirect:/ownerDashboard";
		} catch (Exception e) {
			model.addAttribute("errorMessage", "An error occurred while adding the product: " + e.getMessage());
			return "ownerDashboard";
		}
	}

	@PostMapping("/deleteProduct/{id}")
	public String deleteProduct(@PathVariable Long id, HttpSession session) {
		// Ensure the owner is logged in
		String ownerEmail = (String) session.getAttribute("ownerEmail");
		if (ownerEmail == null) {
			return "redirect:/ownerLogin";
		}

		// Find the product by ID
		Optional<Products> productOptional = productsRepository.findById(id);

		if (productOptional.isPresent()) {
			Products product = productOptional.get();

			// Ensure the logged-in owner owns the product
			if (!ownerEmail.equals(product.getOwner())) {
				return "redirect:/ownerDashboard";
			}

			// Delete the product
			productsRepository.delete(product);
		} else {
		}

		// Redirect back to the owner dashboard
		return "redirect:/ownerDashboard";
	}
	
	@GetMapping("/displayshops")
	public String displayshops(Model model) {
		List<OwnerDetails> details = ownerRepository.findAll();
		model.addAttribute("shops",details);
		return "displayshops";
	}
	
	@GetMapping("/ownerOrders")
	public String getOwnerOrders(Model model, HttpSession session) {
	    // Retrieve the owner email from the session
	    String ownerEmail = (String) session.getAttribute("ownerEmail");

	    if (ownerEmail == null) {
	        model.addAttribute("errorMessage", "You must be logged in as an owner.");
	        return "redirect:/ownerlogin";  // Redirect to owner login if no email found in session
	    }

	    // Fetch orders where the owner is the logged-in owner
	    List<Orders> orders = ordersRepository.findByOwner(ownerEmail);

	    if (orders.isEmpty()) {
	        model.addAttribute("errorMessage", "No orders found for this owner.");
	    } else {
	        model.addAttribute("orders", orders);
	    }

	    return "ownerorders"; // Return to the orders page for the owner
	}


}
