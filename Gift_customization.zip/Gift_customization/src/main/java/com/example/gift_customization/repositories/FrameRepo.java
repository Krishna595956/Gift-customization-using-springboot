package com.example.gift_customization.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gift_customization.entities.FrameDetails;
import com.example.gift_customization.entities.MugDetails;

public interface FrameRepo extends JpaRepository<FrameDetails,Long> {

	List<FrameDetails> findByOwner(String attribute);

	List<FrameDetails> findByRequestedby(String attribute);

}
